# Cosole Based Chat Application

It is an console based chat application

1) main.cpp from server side cpp code
2) Then run clientorg.cpp from client side code

here you can create multiple clinets to send and receive message, you just have to copy and paste the clientorg.cpp file as many client you want
